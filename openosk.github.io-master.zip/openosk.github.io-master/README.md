NOSK is the Open Source club which has been originated from the FOSS/OSHW enthusiastic students from NCIT (Nepal College of Information Technology), Balkumari, Lalitpur, Nepal about 8 years ago. We were listed as the one of the most deserving team in SFD2010. With more passion and motivation we celebraed SFD2011, SFD2012, SFD2013. And this year too we are highly motivated and enthusiastic about the event.

We invite anyone interested to join us.
<br><a href="https://nosk.org.np" target="_blank">NOSK Website</a>
<br><a href="https://sfd.nosk.org.np" target="_blank">NOSK SFD Website</a>

Credits:
<br><a href="https://plus.google.com/117033653342150505949/about" target="_blank">Prakash Yadav</a>
<br><a href="https://www.facebook.com/greyhatanit" target="_blank">Anit Chaudhary</a>
<br><a href="https://plus.google.com/+RajKumarShrestha/about" target="_blank">Raj Kumar Shrestha</a>
<br><a href="https://google.com/+DipeshKumar" target="_blank">Dipesh Kumar</a>

Special Thanks To:
<br><a href="https://developers.google.com" target="_blank">Google Developers Group</a>
<br><a href="https://plus.google.com/+GDGXProject/videos" target="_blank">GDG[x]</a>
